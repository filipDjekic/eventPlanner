namespace EventOrganizerAPI.Models.Enums
{
    public enum TipStatus
    {
        Aktivno,
        Neaktivno,
        Otkazano,
        Zauzeto
    }
}
