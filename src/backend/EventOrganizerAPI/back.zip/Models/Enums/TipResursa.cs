namespace EventOrganizerAPI.Models.Enums
{
    public enum TipResursa
    {
        Osoblje = 0,
        Oprema = 1,
        Hrana = 2,
        Tehnika = 3,
        Scena = 4,
        Drugo = 5
    }
}
