namespace EventOrganizerAPI.Models.Enums
{
    public enum TipTagova
    {
        Muzika,
        Sport,
        Tehnologija,
        Umetnost,
        Porodicni,
        Poslovni
    }
}
