﻿namespace EventOrganizerAPI.Models.Enums
{
    public enum  StatusResursa
    {
        Slobodan,
        Rezervisan
    }
}
