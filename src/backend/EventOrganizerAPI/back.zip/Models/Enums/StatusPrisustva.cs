﻿namespace EventOrganizerAPI.Models.Enums
{
    public enum StatusPrisustva
    {
        Prisutan,
        NijePrisutan
    }
}
