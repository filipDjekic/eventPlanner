namespace EventOrganizerAPI.Models.Enums
{
    public enum TipKarte
    {
        Regular,
        VIP,
        Besplatna,
        RaniPristup
    }
}