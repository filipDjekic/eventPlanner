namespace EventOrganizerAPI.Models.Enums
{
    public enum TipAktivnosti
    {
        Koncert,
        Predavanje,
        Igrica,
        Izlozba,
        Radionica,
        Druzenje,
        Ostalo
    }
}
