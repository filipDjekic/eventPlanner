namespace EventOrganizerAPI.Models.Enums
{
    public enum TipNotifikacije
    {
        Informacija,
        Upozorenje,
        Hitno
    }
}
