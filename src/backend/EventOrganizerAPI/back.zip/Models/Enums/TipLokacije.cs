namespace EventOrganizerAPI.Models.Enums
{
    public enum TipLokacijeEnum
    {
        Bina,
        InfoPult,
        Toalet,
        PunktZaHranuIPice,
        Radionica,
        IzlozbeniStand,
        Ulaz,
        Izlaz,
        KantaZaOtpad,
        Parking,
        Bilaternica

    }
}
