namespace EventOrganizerAPI.Models.Enums
{
    public enum TipNapomeneEnum
    {
        Ulaz,
        Ponasanje
    }
}
