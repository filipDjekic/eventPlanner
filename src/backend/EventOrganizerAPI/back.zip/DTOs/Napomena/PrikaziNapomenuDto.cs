﻿namespace EventOrganizerAPI.DTOs.Napomena
{
    public class PrikaziNapomenuDto
    {
        public string Id { get; set; }
        public string Sadrzaj { get; set; }
        public string Tip { get; set; }
        public string Dogadjaj { get; set; }
    }
}
