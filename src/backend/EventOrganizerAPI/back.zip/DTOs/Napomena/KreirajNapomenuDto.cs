namespace EventOrganizerAPI.DTOs.Napomena
{
    public class KreirajNapomenuDto
    {
        public string Sadrzaj { get; set; }
        public string Tip { get; set; }
        public string Dogadjaj { get; set; }
    }
}
