namespace EventOrganizerAPI.DTOs.Napomena
{
    public class AzurirajNapomenuDto
    {
        public string Id { get; set; }
        public string? Sadrzaj { get; set; }
        public string? Tip { get; set; }
    }
}
