﻿namespace EventOrganizerAPI.DTOs.Resurs
{
    public class PonistiRezervacijuDto
    {
        public string ResursId { get; set; }
        public string DogadjajId { get; set; }
    }
}