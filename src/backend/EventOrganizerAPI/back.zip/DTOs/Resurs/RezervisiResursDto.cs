﻿namespace EventOrganizerAPI.DTOs.Resurs
{
    public class RezervisiResursDto
    {
        public string ResursId { get; set; }
        public string DogadjajId { get; set; }
        public int? Kolicina { get; set; }
    }
}
