﻿namespace EventOrganizerAPI.DTOs.Korisnik
{
    public class DodajBalansDto
    {
        public string KorisnikId { get; set; }
        public decimal Balans { get; set; }
    }
}
