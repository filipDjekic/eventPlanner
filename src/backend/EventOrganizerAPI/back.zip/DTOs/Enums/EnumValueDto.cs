
using System;

namespace EventOrganizerAPI.DTOs.Enums
{
    public class EnumValueDto
    {
        public string Name { get; set; } = string.Empty;
        public int Value { get; set; }
    }
}
