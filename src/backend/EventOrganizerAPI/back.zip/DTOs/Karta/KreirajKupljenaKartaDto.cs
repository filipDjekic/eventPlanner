﻿namespace EventOrganizerAPI.DTOs.Karta
{
    public class KreirajKupljenaKartaDto
    {
        public string IdKarte { get; set; }
        public string KorisnikId { get; set; }
    }
}
