﻿namespace EventOrganizerAPI.DTOs.Organizator
{
    public class PromeniSifruDto
    {
        public string OrganizatorId { get; set; }
        public string TrenutnaSifra { get; set; }
        public string NovaSifra { get; set; }
    }
}