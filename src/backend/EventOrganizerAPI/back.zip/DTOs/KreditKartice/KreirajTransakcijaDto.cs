namespace EventOrganizerAPI.DTOs
{
    public class KreirajTransakcijaDto
    {
        public string KarticaId { get; set; }
        public decimal Iznos { get; set; }
        public string Opis { get; set; }
    }
}
