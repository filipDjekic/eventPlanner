namespace EventOrganizerAPI.DTOs
{
    public class StanjeKarticeDto
    {
        public string KarticaId { get; set; }
        public decimal Stanje { get; set; }
    }
}
