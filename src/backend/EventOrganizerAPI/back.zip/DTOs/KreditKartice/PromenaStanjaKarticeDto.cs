﻿namespace EventOrganizerAPI.DTOs
{
    public class PromenaStanjaKarticeDto
    {
        public string KarticaId { get; set; }
        public decimal Iznos { get; set; }
    }
}
