namespace EventOrganizerAPI.DTOs
{
    public class KreirajKarticaDto
    {
        public string KorisnikId { get; set; }
        public string BrojKartice { get; set; }
        public string ImeVlasnika { get; set; }
        public string DatumIsteka { get; set; }
    }
}
