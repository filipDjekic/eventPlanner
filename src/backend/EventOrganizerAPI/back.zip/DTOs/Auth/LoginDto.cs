namespace EventOrganizerAPI.DTOs.Auth
{
    public class LoginDto
    {
        public string KorisnickoIme { get; set; }
        public string Sifra { get; set; }
        
    }
}
