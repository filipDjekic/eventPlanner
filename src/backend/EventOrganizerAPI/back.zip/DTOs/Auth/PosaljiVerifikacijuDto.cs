namespace EventOrganizerAPI.DTOs
{
    public class PosaljiVerifikacijuDto
    {
        public string email { get; set; }
    }
}
