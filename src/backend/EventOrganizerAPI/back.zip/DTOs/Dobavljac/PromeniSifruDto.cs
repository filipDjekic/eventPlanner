﻿namespace EventOrganizerAPI.DTOs.Dobavljac
{
    public class PromeniSifruDto
    {
        public string TrenutnaSifra { get; set; }
        public string NovaSifra { get; set; }
    }
}